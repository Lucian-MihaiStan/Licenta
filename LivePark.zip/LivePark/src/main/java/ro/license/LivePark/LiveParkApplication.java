package ro.license.LivePark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiveParkApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiveParkApplication.class, args);
	}

}
